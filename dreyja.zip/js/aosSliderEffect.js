AOS.init({
    duration: 3000,
    once: true,
});